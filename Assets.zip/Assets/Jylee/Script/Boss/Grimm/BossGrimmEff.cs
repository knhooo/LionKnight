using UnityEngine;

public class BossGrimmEff : MonoBehaviour
{
    private void SelfDestroy() => Destroy(gameObject);
}
