using UnityEngine;

public class BossAnimationTrigger : MonoBehaviour
{

    private BossBase boss => GetComponent<BossBase>();

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
